#include <stdarg.h>
#include <unistd.h>
#include <stdlib.h>

int lenght_finder(int num)
{
    int i = 0;
    while (num )
    {

        i++;
        num/=10;
    }
    return i;
}

int lenght_finder2(int num)
{
    int i = 0;
    while (num )
    {

        i++;
        num/=16;
    }
    return i;
}

int ft_putchar(char c)
{
    write(1,&c,1);
    return 1;
}

int ft_putstr(char *str)
{
    int len = 0;

    while (*str)
    {
        len+=ft_putchar(*str);
        str++;
    }
    return len;
}

int ft_putnbr(int num)
{
    if (num == -2147483648)
    {
        ft_putstr("-2147483648");
        return 11;
    }
    else if(num < 0)
    {
        ft_putchar('-');
        num=num*-1;
        ft_putchar(num);
    }
    else if(num < 10)
    {
        ft_putchar(num+48);
        return 1;
    }
    else
        ft_putnbr(num/10);
    ft_putnbr(num%10);
    return lenght_finder(num);
}

int ft_puthex(unsigned int num)
{
    if(num < 16)
    {
        ft_putchar("0123456789abcdef"[num]);
        return 1;
    }
    else
        ft_puthex(num/16);
    ft_puthex(num%16);
    return lenght_finder2(num);
}

int ft_what_is(char c, va_list ap)
{
    int len;

    len = 0;
    if (c == 's')
        len += ft_putstr(va_arg(ap,char *));
    else if (c == 'd')
        len += ft_putnbr(va_arg(ap,int));
    else if (c == 'x')
        len += ft_puthex(va_arg(ap,unsigned int));
    else if (c == '%')
        len += ft_putchar('%');
    else
        len += ft_putchar('%');
}

int ft_printf(const char *first_arg, ...)
{
    va_list ap;
    int text_len;

    text_len = 0;
    va_start(ap,first_arg);
    while (*first_arg)
    {
        if(*(first_arg)=='%')
        {
            text_len+=ft_what_is(*(first_arg+1),ap);
            if((*(first_arg+1)!='\0')&&*(first_arg+1)!=' ')
            first_arg++;
        }
        else
            text_len+=ft_putchar(*first_arg);
            first_arg++; 
    }
    return text_len;
}


int main ()
{
    ft_printf("\n%d",ft_printf("%x  % %g",15252));
}