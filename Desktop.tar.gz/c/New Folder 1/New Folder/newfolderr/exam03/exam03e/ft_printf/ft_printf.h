#ifndef FT_PRINTF_H
#define FT_PRINTF_H
# include <stdarg.h>
# include <stdio.h>
# include <unistd.h>

int ft_printf(const char * first_arg, ...);

int what_is(char c, va_list ap);
int ft_putnbr(int num);
int ft_puthex(unsigned int num);
int ft_putstr(char *c);
int ft_putchar(char c);
int hex_digit(unsigned int num);
int num_digit(int num);
#endif