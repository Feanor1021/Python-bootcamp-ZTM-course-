#include "ft_printf.h"




int ft_printf(const char * first, ...)
{
    va_list ap;
    int len;
    len = 0;
    va_start(ap,first);
    while(*first)
    {
        if(*first == '%')
        {
            len+=what_is(*(first+1),ap);
            first++;
        }
        else
            len+=ft_putchar();
        first++;
    }
    va_end(ap);
    return len;
}