#ifndef FT_PRINTF_H
# define FT_PRINTF_H

#include <stdarg.h>
#include <unistd.h>
int ft_printf(const char * first, ...);
int what_is(char c, va_list ap);
int ft_puthex(unsigned int num);
int hex_digit_num(unsigned int num);
int ft_putnbr(int num);
int ret_digit_num(int num);
int ft_putstr(char *c);
int ft_putchar(char c);
#endif