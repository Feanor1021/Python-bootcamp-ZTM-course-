#include "ft_printf.h"
#include <stdio.h>

int ft_putchar(char c)
{
    write(1,&c,1);
    return 1;
}

int ft_putstr(char *c)
{
    int tot_len = 0;
    
    if(!c)
    {
        write(1,"(null)",6);
        return 6;
    }
    while(*c)
    {
        tot_len+=ft_putchar(*c);
        c++;
    }
    return tot_len;
}

int ret_digit_num(int num)
{
    int ret = 0;

    if(num == 0)
        return 1;
    if (num < 0)
    {
                ret++;
                num *=-1;
    }
    while(num>0)
    {
        ret++;
        num/=10;
    }

    return ret;
}
int ft_putnbr(int num)
{
    int len;
    
    len =ret_digit_num(num);
    if(num == -2147483648)
    {
        write(1,"-2147483648",11);
        return 11;
    }
    else if(num < 0)
    {
        write(1,"-",1);
        num=num*-1;
    }
    if(num <10)
    {
        ft_putchar(48+num);
        return len;
    }
    else
        ft_putnbr(num/10);
    ft_putnbr(num%10);
    return len;
}

int hex_digit_num(unsigned int num)
{
    int ret = 0;

    if(num == 0)
        return 1;
    while(num)
    {
        ret++;
        num/=16;
    }
    return ret;
}

int ft_puthex(unsigned int num)
{
    int len = hex_digit_num(num);

    if(num <16)
    {
        ft_putchar("0123456789abcdef"[num]);
        return len;
    }
    else
        ft_puthex(num/16);
    ft_puthex(num%16);
    return len;
}

int what_is(char c, va_list ap)
{
    int len = 0;

    if(c == 's')
        len += ft_putstr(va_arg(ap,char *));
    else if(c == 'd')
        len += ft_putnbr(va_arg(ap,int));
    else if (c == 'x')
        len += ft_puthex(va_arg(ap,unsigned int));
    else if(c == '%')
        len+=ft_putchar('%');
    else
        return len;
    return len;
}

int ft_printf(const char * first, ...)
{
    va_list ap;
    int tot_long;

    tot_long = 0;
    va_start(ap, first);
    while(*first)
    {
        if(*first=='%')
        {
            tot_long+=what_is(*(first+1),ap);
            first++;
        }
        else
            tot_long+=ft_putchar(*first);
        first++;
    }
    va_end(ap);
    return tot_long;
}
