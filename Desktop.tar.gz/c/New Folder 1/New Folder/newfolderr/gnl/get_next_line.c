#include "get_next_line.h"

char *get_next_line(int fd)
{
    char *buf=(char *)malloc(sizeof(char)*(10000));
    int rd=1;
    int i=0;
    int character;

    while ((rd=read(fd,&character,1))>0)
    {
        buf[i]=character;
        if(character == '\n')
            break;
        i++;
    }
    if((!buf[i-1]&&!rd)||(rd == -1))
    {
        free(buf);
        return NULL;
    }
    buf[i]='\0';
    return buf;
}

int main()
{
    int a=open("deneme.txt",O_RDONLY);
    char *c;
    

    while(c=get_next_line(a))
    {
        printf("%s\n",c);
        free(c);
    }
    return 1;
}