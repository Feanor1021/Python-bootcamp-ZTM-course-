#include <unistd.h>

int is_prime(int num)
{
	int i = 3;
	
	if (num <= 1)
		return (0);
	if (num % 2 == 0 && num > 2)
		return (0);
	while (i < (num / 2))
	{
		if (num % i == 0)
			return 0;
		i += 2;
	}
	return 1;
}

int ft_atoi(char *nbr)
{
    int num;
    int sign;

    num = 0;
    sign = 1;
    while(*nbr==' '|| *nbr <=13 && *nbr >=9)
    nbr++;
    if(*nbr == '-' || *nbr =='+')
    {
        if(*nbr == '-')
        sign = -1;
        nbr++;
    }
    while(*nbr <='9' && *nbr >='0')
    {
        num = (*nbr-48)+num*10;
        nbr++;
    }
    return num*sign;
}

void ft_putchar(char c)
{
    write(1,&c,1);
}

void ft_putnbr(int nbr)
{
    if(nbr == -2147483648)
    {
        write(1,"-2147483648",11);
        return ;
    }
    else if(nbr < 0)
    {
        nbr *= -1;
        ft_putnbr(nbr);
    }
    else if(nbr < 10)
    {
       ft_putchar(nbr+48);
       return;
    }
    else
    ft_putnbr(nbr/10);
    ft_putnbr(nbr%10);
}

int main(int argc, char *argv[])
{
	int sum = 0;
	int nb = ft_atoi(argv[1]);
	
	if (argc == 2)
	{
		while (nb > 0)
			if (is_prime(nb--))
				sum += (nb + 1);
		ft_putnbr(sum);
	}
	if (argc != 2)
		ft_putnbr(0);
	write(1, "\n", 1);
	return (0);
}