


void    *mlx_png_file_to_image(void *xvar, char *file, int *width, int *height);
