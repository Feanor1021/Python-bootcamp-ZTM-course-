code for the pyviz.py file is:
python3 pyviz.py `ruby -e "puts (1..499).to_a.shuffle.join(' ')"`
